#ifndef NODE_H
#define NODE_H
#include "AbstractSerializer.h"

class Node : public AbstractSerializer
{
public:
	Node(const int& _id);
	~Node();

	void Serialize(std::ostream& _os) override;
	void Deserialize(std::istream& _is) override;

private:
	int m_id;
};

#endif // NODE_H
