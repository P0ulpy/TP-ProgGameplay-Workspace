#ifndef ABSTRACTSERIALIZER_H
#define ABSTRACTSERIALIZER_H
#include <iosfwd>
#include <string>

class AbstractSerializer
{
public:
	AbstractSerializer() = default;
	virtual ~AbstractSerializer() = default;

	void Save(const std::string& _path);
	void Load();

protected:
	virtual void Serialize(std::ostream& _os) = 0;
	virtual void Deserialize(std::istream& _is) = 0;
};

#endif // ABSTRACTSERIALIZER_H
