#include "AbstractSerializer.h"
#include <fstream>

void AbstractSerializer::Save(const std::string& _path)
{
	std::filebuf output;
	output.open(_path, std::ios::out);
	if (!output.is_open())
		return;

	std::ostream os(&output);
	Serialize(os);
	output.close();
}

void AbstractSerializer::Load()
{
}
