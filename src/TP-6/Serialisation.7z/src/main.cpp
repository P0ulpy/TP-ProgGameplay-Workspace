#include "Node.h"
#include <iostream>

int main()
{
	std::unique_ptr<AbstractSerializer> node = std::make_unique<Node>(3);

	node->Save("C:/node.txt");
	return 0;
}