#include "Node.h"
#include <iostream>

Node::Node(const int& _id)
	: m_id(_id)
{
}

Node::~Node()
{
}

void Node::Serialize(std::ostream& _os)
{
	_os << m_id;
}

void Node::Deserialize(std::istream& _is)
{
	_is >> m_id;
}
